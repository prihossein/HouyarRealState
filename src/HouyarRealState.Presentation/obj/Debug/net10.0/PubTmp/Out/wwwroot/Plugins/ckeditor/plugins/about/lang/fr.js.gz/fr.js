﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'fr', {
	copy: 'Copyright &copy; $1. Tous droits réservés.',
	dlgTitle: 'À propos de CKEditor 4',
	moreInfo: 'Pour les informations de licence, veuillez visiter notre site web :'
} );
