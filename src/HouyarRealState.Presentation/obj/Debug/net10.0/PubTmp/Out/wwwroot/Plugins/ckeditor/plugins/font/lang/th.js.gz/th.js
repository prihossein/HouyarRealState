/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'font', 'th', {
	fontSize: {
		label: 'ขนาด',
		voiceLabel: 'Font Size',
		panelTitle: 'ขนาด'
	},
	label: 'แบบอักษร',
	panelTitle: 'แบบอักษร',
	voiceLabel: 'แบบอักษร'
} );
