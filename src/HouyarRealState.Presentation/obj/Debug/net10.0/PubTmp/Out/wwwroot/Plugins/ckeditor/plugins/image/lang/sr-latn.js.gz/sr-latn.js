﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image', 'sr-latn', {
	alt: 'Alternativni tekst',
	border: 'Okvir',
	btnUpload: 'Pošalji na server',
	button2Img: 'Do you want to transform the selected image button on a simple image?', // MISSING
	hSpace: 'HSpace',
	img2Button: 'Do you want to transform the selected image on a image button?', // MISSING
	infoTab: 'Info slike',
	linkTab: 'Link',
	lockRatio: 'Zaključaj odnos',
	menu: 'Osobine slika',
	resetSize: 'Resetuj veličinu',
	title: 'Osobine slika',
	titleButton: 'Osobine dugmeta sa slikom',
	upload: 'Pošalji',
	urlMissing: 'Image source URL is missing.', // MISSING
	vSpace: 'VSpace',
	validateBorder: 'Border must be a whole number.', // MISSING
	validateHSpace: 'HSpace must be a whole number.', // MISSING
	validateVSpace: 'VSpace must be a whole number.' // MISSING
} );
