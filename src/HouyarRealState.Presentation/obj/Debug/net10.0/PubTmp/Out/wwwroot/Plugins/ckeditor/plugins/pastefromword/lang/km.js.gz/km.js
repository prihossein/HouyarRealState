﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'km', {
	confirmCleanup: 'អត្ថបទ​ដែល​អ្នក​ចង់​បិទ​ភ្ជាប់​នេះ ទំនង​ដូច​ជា​ចម្លង​មក​ពី Word។ តើ​អ្នក​ចង់​សម្អាត​វា​មុន​បិទ​ភ្ជាប់​ទេ?',
	error: 'ដោយ​សារ​មាន​បញ្ហា​ផ្នែក​ក្នុង​ធ្វើ​ឲ្យ​មិន​អាច​សម្អាត​ទិន្នន័យ​ដែល​បាន​បិទ​ភ្ជាប់',
	title: 'បិទ​ភ្ជាប់​ពី Word',
	toolbar: 'បិទ​ភ្ជាប់​ពី Word'
} );
