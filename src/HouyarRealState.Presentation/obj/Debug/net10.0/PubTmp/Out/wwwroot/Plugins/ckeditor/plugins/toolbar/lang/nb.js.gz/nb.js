﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'nb', {
	toolbarCollapse: 'Skjul verktøylinje',
	toolbarExpand: 'Vis verktøylinje',
	toolbarGroups: {
		document: 'Dokument',
		clipboard: 'Utklippstavle/Angre',
		editing: 'Redigering',
		forms: 'Skjema',
		basicstyles: 'Basisstiler',
		paragraph: 'Avsnitt',
		links: 'Lenker',
		insert: 'Innsetting',
		styles: 'Stiler',
		colors: 'Farger',
		tools: 'Verktøy'
	},
	toolbars: 'Verktøylinjer for editor'
} );
