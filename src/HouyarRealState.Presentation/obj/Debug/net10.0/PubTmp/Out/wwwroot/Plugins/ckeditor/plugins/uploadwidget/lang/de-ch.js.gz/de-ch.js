﻿/**
 * @license Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.plugins.setLang( 'uploadwidget', 'de-ch', {
	abort: 'Hochladen durch den Benutzer abgebrochen.',
	doneOne: 'Datei erfolgreich hochgeladen.',
	doneMany: '%1 Dateien erfolgreich hochgeladen.',
	uploadOne: 'Datei wird hochgeladen ({percentage}%)...',
	uploadMany: 'Dateien werden hochgeladen, {current} von {max} fertig ({percentage}%)...'
} );
