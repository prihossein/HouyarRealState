﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'gu', {
	copy: 'કોપીરાઈટ &copy; $1. ઓલ રાઈટ્સ ',
	dlgTitle: 'CKEditor વિષે',
	moreInfo: 'લાયસનસની માહિતી માટે અમારી વેબ સાઈટ'
} );
