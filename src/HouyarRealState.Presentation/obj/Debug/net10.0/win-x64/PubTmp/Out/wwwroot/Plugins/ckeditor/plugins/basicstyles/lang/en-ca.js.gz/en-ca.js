﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'en-ca', {
	bold: 'Bold',
	italic: 'Italic',
	strike: 'Strike Through',
	subscript: 'Subscript',
	superscript: 'Superscript',
	underline: 'Underline'
} );
