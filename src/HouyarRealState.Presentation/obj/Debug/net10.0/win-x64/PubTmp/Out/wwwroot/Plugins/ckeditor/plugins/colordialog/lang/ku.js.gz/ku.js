﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'ku', {
	clear: 'پاکیکەوە',
	highlight: 'نیشانکردن',
	options: 'هەڵبژاردەی ڕەنگەکان',
	selected: 'ڕەنگی هەڵبژێردراو',
	title: 'هەڵبژاردنی ڕەنگ'
} );
