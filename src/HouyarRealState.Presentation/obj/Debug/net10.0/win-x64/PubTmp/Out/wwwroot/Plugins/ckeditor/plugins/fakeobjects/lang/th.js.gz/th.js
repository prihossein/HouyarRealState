﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'th', {
	anchor: 'แทรก/แก้ไข Anchor',
	flash: 'ภาพอนิเมชั่นแฟลช',
	hiddenfield: 'ฮิดเดนฟิลด์',
	iframe: 'IFrame',
	unknown: 'วัตถุไม่ทราบชนิด'
} );
