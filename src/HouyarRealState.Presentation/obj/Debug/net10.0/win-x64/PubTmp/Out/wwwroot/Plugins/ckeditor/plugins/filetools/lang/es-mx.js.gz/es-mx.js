﻿/**
 * @license Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'filetools', 'es-mx', {
	loadError: 'Ha ocurrido un error al leer el archivo',
	networkError: 'Ha ocurrido un error de red durante la carga del archivo.',
	httpError404: 'Se ha producido un error HTTP durante la subida de archivos (404: archivo no encontrado).',
	httpError403: 'Se ha producido un error HTTP durante la subida de archivos (403: Prohibido).',
	httpError: 'Se ha producido un error HTTP durante la subida de archivos (error: %1).',
	noUrlError: 'La URL de subida no está definida.',
	responseError: 'Respuesta incorrecta del servidor.'
} );
