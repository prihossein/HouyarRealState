﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'et', {
	label: 'Vorming',
	panelTitle: 'Vorming',
	tag_address: 'Aadress',
	tag_div: 'Tavaline (DIV)',
	tag_h1: 'Pealkiri 1',
	tag_h2: 'Pealkiri 2',
	tag_h3: 'Pealkiri 3',
	tag_h4: 'Pealkiri 4',
	tag_h5: 'Pealkiri 5',
	tag_h6: 'Pealkiri 6',
	tag_p: 'Tavaline',
	tag_pre: 'Vormindatud'
} );
