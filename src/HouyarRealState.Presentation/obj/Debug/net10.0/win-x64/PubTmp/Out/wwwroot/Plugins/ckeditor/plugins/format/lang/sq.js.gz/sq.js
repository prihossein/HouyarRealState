﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'sq', {
	label: 'Formati',
	panelTitle: 'Formati i Paragrafit',
	tag_address: 'Adresa',
	tag_div: 'Normal (DIV)',
	tag_h1: 'Titulli 1',
	tag_h2: 'Titulli 2',
	tag_h3: 'Titulli 3',
	tag_h4: 'Titulli 4',
	tag_h5: 'Titulli 5',
	tag_h6: 'Titulli 6',
	tag_p: 'Normal',
	tag_pre: 'Formatuar'
} );
