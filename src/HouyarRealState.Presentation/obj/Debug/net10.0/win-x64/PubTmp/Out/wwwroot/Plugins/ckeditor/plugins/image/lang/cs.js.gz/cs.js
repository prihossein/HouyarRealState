﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image', 'cs', {
	alt: 'Alternativní text',
	border: 'Okraje',
	btnUpload: 'Odeslat na server',
	button2Img: 'Skutečně chcete převést zvolené obrázkové tlačítko na obyčejný obrázek?',
	hSpace: 'Horizontální mezera',
	img2Button: 'Skutečně chcete převést zvolený obrázek na obrázkové tlačítko?',
	infoTab: 'Informace o obrázku',
	linkTab: 'Odkaz',
	lockRatio: 'Zámek',
	menu: 'Vlastnosti obrázku',
	resetSize: 'Původní velikost',
	title: 'Vlastnosti obrázku',
	titleButton: 'Vlastností obrázkového tlačítka',
	upload: 'Odeslat',
	urlMissing: 'Zadané URL zdroje obrázku nebylo nalezeno.',
	vSpace: 'Vertikální mezera',
	validateBorder: 'Okraj musí být nastaven v celých číslech.',
	validateHSpace: 'Horizontální mezera musí být nastavena v celých číslech.',
	validateVSpace: 'Vertikální mezera musí být nastavena v celých číslech.'
} );
