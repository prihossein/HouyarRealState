﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'link', 'ug', {
	acccessKey: 'زىيارەت كۇنۇپكا',
	advanced: 'ئالىي',
	advisoryContentType: 'مەزمۇن تىپى',
	advisoryTitle: 'ماۋزۇ',
	anchor: {
		toolbar: 'لەڭگەرلىك نۇقتا ئۇلانمىسى قىستۇر/تەھرىرلە',
		menu: 'لەڭگەرلىك نۇقتا ئۇلانما خاسلىقى',
		title: 'لەڭگەرلىك نۇقتا ئۇلانما خاسلىقى',
		name: 'لەڭگەرلىك نۇقتا ئاتى',
		errorName: 'لەڭگەرلىك نۇقتا ئاتىنى كىرگۈزۈڭ',
		remove: 'لەڭگەرلىك نۇقتا ئۆچۈر'
	},
	anchorId: 'لەڭگەرلىك نۇقتا ID سى بويىچە',
	anchorName: 'لەڭگەرلىك نۇقتا ئاتى بويىچە',
	charset: 'ھەرپ كودلىنىشى',
	cssClasses: 'ئۇسلۇب خىلى ئاتى',
	download: 'Force Download', // MISSING
	displayText: 'Display Text', // MISSING
	emailAddress: 'ئادرېس',
	emailBody: 'مەزمۇن',
	emailSubject: 'ماۋزۇ',
	id: 'ID',
	info: 'ئۇلانما ئۇچۇرى',
	langCode: 'تىل كودى',
	langDir: 'تىل يۆنىلىشى',
	langDirLTR: 'سولدىن ئوڭغا (LTR)',
	langDirRTL: 'ئوڭدىن سولغا (RTL)',
	menu: 'ئۇلانما تەھرىر',
	name: 'ئات',
	noAnchors: '(بۇ پۈتۈكتە ئىشلەتكىلى بولىدىغان لەڭگەرلىك نۇقتا يوق)',
	noEmail: 'ئېلخەت ئادرېسىنى كىرگۈزۈڭ',
	noUrl: 'ئۇلانما ئادرېسىنى كىرگۈزۈڭ',
	noTel: 'Please type the phone number', // MISSING
	other: '‹باشقا›',
	phoneNumber: 'Phone number', // MISSING
	popupDependent: 'تەۋە (NS)',
	popupFeatures: 'قاڭقىش كۆزنەك خاسلىقى',
	popupFullScreen: 'پۈتۈن ئېكران (IE)',
	popupLeft: 'سول',
	popupLocationBar: 'ئادرېس بالداق',
	popupMenuBar: 'تىزىملىك بالداق',
	popupResizable: 'چوڭلۇقى ئۆزگەرتىشچان',
	popupScrollBars: 'دومىلىما سۈرگۈچ',
	popupStatusBar: 'ھالەت بالداق',
	popupToolbar: 'قورال بالداق',
	popupTop: 'ئوڭ',
	rel: 'باغلىنىش',
	selectAnchor: 'بىر لەڭگەرلىك نۇقتا تاللاڭ',
	styles: 'قۇر ئىچىدىكى ئۇسلۇبى',
	tabIndex: 'Tab تەرتىپى',
	target: 'نىشان',
	targetFrame: '‹كاندۇك›',
	targetFrameName: 'نىشان كاندۇك ئاتى',
	targetPopup: '‹قاڭقىش كۆزنەك›',
	targetPopupName: 'قاڭقىش كۆزنەك ئاتى',
	title: 'ئۇلانما',
	toAnchor: 'بەت ئىچىدىكى لەڭگەرلىك نۇقتا ئۇلانمىسى',
	toEmail: 'ئېلخەت',
	toUrl: 'ئادرېس',
	toPhone: 'Phone', // MISSING
	toolbar: 'ئۇلانما قىستۇر/تەھرىرلە',
	type: 'ئۇلانما تىپى',
	unlink: 'ئۇلانما بىكار قىل',
	upload: 'يۈكلە'
} );
