﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'ru', {
	options: 'Выбор специального символа',
	title: 'Выберите специальный символ',
	toolbar: 'Вставить специальный символ'
} );
